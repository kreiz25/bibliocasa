import Dexie,{type EntityTable} from 'dexie'
import type {AppSetting,Backup,Book} from './types'
class LibraryDB extends Dexie {books!:EntityTable<Book,'id'>;settings!:EntityTable<AppSetting,'key'>;backups!:EntityTable<Backup,'id'>;constructor(){super('BiblioCasa');this.version(1).stores({books:'id,&isbn,titulo,autor,xenero,lido,data_incorporacion,data_modificacion',settings:'key',backups:'++id,createdAt'});this.version(2).stores({books:'id,&isbn,titulo,autor,xenero,lido,data_incorporacion,data_modificacion',settings:'key',backups:'++id,createdAt'}).upgrade(tx=>tx.table('books').toCollection().modify(book=>{if(typeof book.ano_publicacion!=='string')book.ano_publicacion=''}))}}
export const db=new LibraryDB()
export async function requestPersistence(){try{if(navigator.storage?.persist){const persisted=await navigator.storage.persisted();return persisted||await navigator.storage.persist()}}catch{}return false}
export async function putBook(book:Book){await db.books.put({...book,data_modificacion:new Date().toISOString()})}
export async function saveBackup(books:Book[]){return db.backups.add({createdAt:new Date().toISOString(),formatVersion:2,books:structuredClone(books)})}
