import type {Genre} from './types'
import {normalizeIsbn} from './isbn'

const map:[RegExp,Genre][]=[
 [/historical|hist[oó]ric/i,'Novela histórica'],
 [/(mystery|crime|thriller|detective|negra)/i,'Misterio e novela negra'],
 [/(juvenile|children|young adult|infantil|xuvenil|literatura infantil)/i,'Infantil e xuvenil'],
 [/(science fiction|fantasy|ciencia ficci[oó]n|fantas[ií]a)/i,'Ciencia ficción e fantasía'],
 [/(essay|ensayo|philosophy|nonfiction|ensaio)/i,'Ensaio'],
 [/(history|historia)/i,'Historia'],
 [/(biograph|autobiograph|biograf)/i,'Biografía'],
 [/(poetry|poes[ií]a)/i,'Poesía'],
 [/(religion|spiritual|relixi[oó]n|espiritual)/i,'Relixión e espiritualidade'],
 [/(fiction|novel|literature|ficci[oó]n|novela|literatura)/i,'Narrativa']
]

export function classify(categories:string[]=[]):Genre{
 const text=categories.join(' ')
 return map.find(([re])=>re.test(text))?.[1]??'Sen clasificar'
}

async function fetchJsonWithTimeout(url:string,timeoutMs=9000){
 const controller=new AbortController();let timer:number|undefined
 const timeout=new Promise<never>((_,reject)=>{timer=window.setTimeout(()=>{controller.abort();reject(new Error('A consulta superou o tempo límite.'))},timeoutMs)})
 try{const response=await Promise.race([fetch(url,{signal:controller.signal}),timeout]);if(!response.ok)throw new Error(`Resposta HTTP ${response.status}`);return await response.json()}
 finally{if(timer!==undefined)window.clearTimeout(timer)}
}

async function fetchTextWithTimeout(url:string,timeoutMs=9000){
 const controller=new AbortController();let timer:number|undefined
 const timeout=new Promise<never>((_,reject)=>{timer=window.setTimeout(()=>{controller.abort();reject(new Error('A consulta superou o tempo límite.'))},timeoutMs)})
 try{const response=await Promise.race([fetch(url,{signal:controller.signal}),timeout]);if(!response.ok)throw new Error(`Resposta HTTP ${response.status}`);return await response.text()}
 finally{if(timer!==undefined)window.clearTimeout(timer)}
}

type BookData={title:string;authors:string;publisher:string;year:string;cover:string;categories:string[]}
const emptyData=():BookData=>({title:'',authors:'',publisher:'',year:'',cover:'',categories:[]})
const cleanIdentifier=(value:string)=>normalizeIsbn(value)??value.replace(/[\s-]/g,'').toUpperCase()
const yearFrom=(value:string)=>value.match(/\b(1[5-9]\d{2}|20\d{2}|2100)\b/)?.[0]??''

function localNameValues(root:Element,name:string){
 return Array.from(root.getElementsByTagName('*')).filter(el=>el.localName.toLowerCase()===name.toLowerCase()).map(el=>el.textContent?.trim()??'').filter(Boolean)
}

function bneRecord(xml:string,isbn:string){
 const doc=new DOMParser().parseFromString(xml,'application/xml')
 if(doc.querySelector('parsererror'))throw new Error('A BNE devolveu XML non válido.')
 const records=Array.from(doc.getElementsByTagName('*')).filter(el=>el.localName==='record')
 const parsed=records.map(record=>{
  const recordData=Array.from(record.getElementsByTagName('*')).find(el=>el.localName==='recordData')
  const root=recordData??record
  const identifiers=localNameValues(root,'identifier')
  const ids=identifiers.flatMap(value=>{
   const candidates=value.match(/(?:97[89][\d -]{10,}|[\d -]{9}[\dXx])/g)??[value]
   return candidates.map(cleanIdentifier)
  })
  const title=localNameValues(root,'title')[0]??''
  const creators=localNameValues(root,'creator')
  const publishers=localNameValues(root,'publisher')
  const dates=localNameValues(root,'date')
  return {ids,title,authors:[...new Set(creators)].join(', '),publisher:publishers[0]??'',year:dates.map(yearFrom).find(Boolean)??'',categories:localNameValues(root,'subject')}
 })
 return parsed.find(x=>x.ids.includes(isbn))??(parsed.length===1&&!parsed[0].ids.length?parsed[0]:undefined)
}

async function lookupBne(isbn:string){
 const params=new URLSearchParams({operation:'searchRetrieve',version:'1.2',query:`alma.isbn="${isbn}"`,recordSchema:'dc',startRecord:'1',maximumRecords:'5'})
 const xml=await fetchTextWithTimeout(`https://catalogo.bne.es/view/sru/34BNE_INST?${params}`)
 return bneRecord(xml,isbn)
}

export async function lookupBook(isbn:string){
 const data=emptyData();let googleFailed=false,openLibraryFailed=false,bneFailed=false

 // O identificador devolto pode ser ISBN-10 aínda que a consulta se fixese con ISBN-13.
 try{
  const j=await fetchJsonWithTimeout(`https://www.googleapis.com/books/v1/volumes?q=isbn:${encodeURIComponent(isbn)}&maxResults=10`)
  const v=j.items?.find((x:any)=>x.volumeInfo?.industryIdentifiers?.some((i:any)=>cleanIdentifier(i.identifier)===isbn))
  if(v){const b=v.volumeInfo;data.title=b.title??'';data.authors=(b.authors??[]).join(', ');data.publisher=b.publisher??'';data.year=yearFrom(b.publishedDate??'');data.cover=(b.imageLinks?.extraLarge??b.imageLinks?.large??b.imageLinks?.thumbnail??'').replace('http://','https://');data.categories=b.categories??[]}
 }catch{googleFailed=true}

 // Completa campos que Google non devolveu, aínda que xa se atopase o título.
 if(!data.title||!data.authors||!data.publisher||!data.year||!data.cover){
  try{
   const j=await fetchJsonWithTimeout(`https://openlibrary.org/search.json?isbn=${encodeURIComponent(isbn)}&fields=title,author_name,publisher,subject,isbn,cover_i,first_publish_year&limit=10`)
   const d=j.docs?.find((x:any)=>x.isbn?.some((i:string)=>cleanIdentifier(i)===isbn))
   if(d){data.title ||= d.title??'';data.authors ||= (d.author_name??[]).join(', ');data.publisher ||= d.publisher?.[0]??'';data.year ||= d.first_publish_year?String(d.first_publish_year):'';data.cover ||= d.cover_i?`https://covers.openlibrary.org/b/id/${d.cover_i}-M.jpg`:'';data.categories=[...data.categories,...(d.subject??[])]}
  }catch{openLibraryFailed=true}
 }

 // A BNE é unha fonte máis para libros do seu catálogo e pode completar campos vacíos.
 if(!data.title||!data.authors||!data.publisher||!data.year){
  try{
   const d=await lookupBne(isbn)
   if(d){data.title ||= d.title;data.authors ||= d.authors;data.publisher ||= d.publisher;data.year ||= d.year;data.categories=[...data.categories,...d.categories]}
  }catch{bneFailed=true}
 }

 const found=Boolean(data.title.trim())
 return {found,networkError:googleFailed&&openLibraryFailed&&bneFailed&&!found,title:data.title,authors:data.authors,publisher:data.publisher,year:data.year,cover:data.cover,genre:classify(data.categories)}
}
