import type {Genre} from './types'

const map:[RegExp,Genre][]=[
 [/historical|hist[oó]ric/i,'Novela histórica'],
 [/(mystery|crime|thriller|detective|negra)/i,'Misterio e novela negra'],
 [/(juvenile|children|young adult|infantil|xuvenil)/i,'Infantil e xuvenil'],
 [/(science fiction|fantasy|ciencia ficci[oó]n|fantas[ií]a)/i,'Ciencia ficción e fantasía'],
 [/(essay|ensayo|philosophy|nonfiction)/i,'Ensaio'],
 [/(history|historia)/i,'Historia'],
 [/(biograph|autobiograph|biograf)/i,'Biografía'],
 [/(poetry|poes[ií]a)/i,'Poesía'],
 [/(religion|spiritual|relixi[oó]n|espiritual)/i,'Relixión e espiritualidade'],
 [/(fiction|novel|literature|ficci[oó]n|novela|literatura)/i,'Narrativa']
]

export function classify(categories:string[]=[]):Genre{
 const text=categories.join(' ')
 return map.find(([re])=>re.test(text))?.[1]??'Sen clasificar'
}

async function fetchJsonWithTimeout(url:string,timeoutMs=7000){
 const controller=new AbortController();let timer:number|undefined
 const timeout=new Promise<never>((_,reject)=>{timer=window.setTimeout(()=>{controller.abort();reject(new Error('A consulta superou o tempo límite.'))},timeoutMs)})
 try{const response=await Promise.race([fetch(url,{signal:controller.signal}),timeout]);if(!response.ok)throw new Error(`Resposta HTTP ${response.status}`);return await response.json()}
 finally{if(timer!==undefined)window.clearTimeout(timer)}
}

export async function lookupBook(isbn:string){
 let title='',authors='',publisher='',cover='',categories:string[]=[],googleFailed=false,openLibraryFailed=false
 try{
  const j=await fetchJsonWithTimeout(`https://www.googleapis.com/books/v1/volumes?q=isbn:${encodeURIComponent(isbn)}`)
  const v=j.items?.find((x:any)=>x.volumeInfo?.industryIdentifiers?.some((i:any)=>i.identifier.replace(/[-\s]/g,'')===isbn))
  if(v){const b=v.volumeInfo;title=b.title??'';authors=(b.authors??[]).join(', ');publisher=b.publisher??'';cover=(b.imageLinks?.thumbnail??'').replace('http://','https://');categories=b.categories??[]}
 }catch{googleFailed=true}
 if(!title){
  try{
   const j=await fetchJsonWithTimeout(`https://openlibrary.org/search.json?isbn=${encodeURIComponent(isbn)}&fields=title,author_name,publisher,subject,isbn,cover_i&limit=5`)
   const d=j.docs?.find((x:any)=>x.isbn?.some((i:string)=>i.replace(/[-\s]/g,'')===isbn))
   if(d){title=d.title??'';authors=(d.author_name??[]).join(', ');publisher=d.publisher?.[0]??'';cover=d.cover_i?`https://covers.openlibrary.org/b/id/${d.cover_i}-M.jpg`:'';categories=d.subject??[]}
  }catch{openLibraryFailed=true}
 }
 const found=Boolean(title||authors||publisher||cover)
 return {found,networkError:googleFailed&&openLibraryFailed&&!found,title,authors,publisher,cover,genre:classify(categories)}
}
