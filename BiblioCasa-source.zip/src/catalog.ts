import type {Genre} from './types'
import {normalizeIsbn} from './isbn'

const map:[RegExp,Genre][]=[
 [/historical|hist[oó]ric/i,'Novela histórica'],
 [/(mystery|crime|thriller|detective|negra)/i,'Misterio e novela negra'],
 [/(juvenile|children|young adult|infantil|xuvenil)/i,'Infantil e xuvenil'],
 [/(science fiction|fantasy|ciencia ficci[oó]n|fantas[ií]a)/i,'Ciencia ficción e fantasía'],
 [/(essay|ensayo|philosophy|nonfiction)/i,'Ensaio'],
 [/(history|historia)/i,'Historia'],
 [/(biograph|autobiograph|biograf)/i,'Biografía'],
 [/(poetry|poes[ií]a)/i,'Poesía'],
 [/(religion|spiritual|relixi[oó]n|espiritual)/i,'Relixión e espiritualidade'],
 [/(fiction|novel|literature|ficci[oó]n|novela|literatura)/i,'Narrativa']
]

export function classify(categories:string[]=[]):Genre{
 const text=categories.join(' ')
 return map.find(([re])=>re.test(text))?.[1]??'Sen clasificar'
}

async function fetchJsonWithTimeout(url:string,timeoutMs=9000){
 const controller=new AbortController();let timer:number|undefined
 const timeout=new Promise<never>((_,reject)=>{timer=window.setTimeout(()=>{controller.abort();reject(new Error('A consulta superou o tempo límite.'))},timeoutMs)})
 try{const response=await Promise.race([fetch(url,{signal:controller.signal}),timeout]);if(!response.ok)throw new Error(`Resposta HTTP ${response.status}`);return await response.json()}
 finally{if(timer!==undefined)window.clearTimeout(timer)}
}

type BookData={title:string;authors:string;publisher:string;cover:string;categories:string[]}
const emptyData=():BookData=>({title:'',authors:'',publisher:'',cover:'',categories:[]})
const cleanIdentifier=(value:string)=>normalizeIsbn(value)??value.replace(/[\s-]/g,'').toUpperCase()

export async function lookupBook(isbn:string){
 const data=emptyData();let googleFailed=false,openLibraryFailed=false

 // O identificador devolto pode ser ISBN-10 aínda que a consulta se fixese con ISBN-13.
 try{
  const j=await fetchJsonWithTimeout(`https://www.googleapis.com/books/v1/volumes?q=isbn:${encodeURIComponent(isbn)}&maxResults=10`)
  const v=j.items?.find((x:any)=>x.volumeInfo?.industryIdentifiers?.some((i:any)=>cleanIdentifier(i.identifier)===isbn))
  if(v){const b=v.volumeInfo;data.title=b.title??'';data.authors=(b.authors??[]).join(', ');data.publisher=b.publisher??'';data.cover=(b.imageLinks?.extraLarge??b.imageLinks?.large??b.imageLinks?.thumbnail??'').replace('http://','https://');data.categories=b.categories??[]}
 }catch{googleFailed=true}

 // Completa os campos que Google non devolveu, aínda que xa se atopase o título.
 if(!data.title||!data.authors||!data.publisher||!data.cover){
  try{
   const j=await fetchJsonWithTimeout(`https://openlibrary.org/search.json?isbn=${encodeURIComponent(isbn)}&fields=title,author_name,publisher,subject,isbn,cover_i&limit=10`)
   const d=j.docs?.find((x:any)=>x.isbn?.some((i:string)=>cleanIdentifier(i)===isbn))
   if(d){data.title ||= d.title??'';data.authors ||= (d.author_name??[]).join(', ');data.publisher ||= d.publisher?.[0]??'';data.cover ||= d.cover_i?`https://covers.openlibrary.org/b/id/${d.cover_i}-M.jpg`:'';data.categories=[...data.categories,...(d.subject??[])]}
  }catch{openLibraryFailed=true}
 }

 const found=Boolean(data.title.trim())
 return {found,networkError:googleFailed&&openLibraryFailed&&!found,title:data.title,authors:data.authors,publisher:data.publisher,cover:data.cover,genre:classify(data.categories)}
}
