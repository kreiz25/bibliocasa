export const GENRES=['Narrativa','Novela histórica','Misterio e novela negra','Ciencia ficción e fantasía','Ensaio','Historia','Biografía','Poesía','Infantil e xuvenil','Relixión e espiritualidade','Outros','Sen clasificar'] as const
export type Genre=typeof GENRES[number]
export interface Book {id:string;isbn:string;titulo:string;autor:string;editorial:string;xenero:Genre;portada_url:string;lido:boolean;data_incorporacion:string;data_modificacion:string}
export interface AppSetting {key:string;value:unknown}
export interface Backup {id?:number;createdAt:string;formatVersion:number;books:Book[]}
export interface BackupFile {app:'BiblioCasa';formatVersion:number;createdAt:string;books:Book[]}
export const newBook=(isbn=''):Book=>({id:crypto.randomUUID(),isbn,titulo:'',autor:'',editorial:'',xenero:'Sen clasificar',portada_url:'',lido:false,data_incorporacion:new Date().toISOString(),data_modificacion:new Date().toISOString()})
