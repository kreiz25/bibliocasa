import {useCallback,useEffect,useRef,useState} from 'react'
import {BarcodeFormat,DecodeHintType} from '@zxing/library'
import {BrowserMultiFormatReader,type IScannerControls} from '@zxing/browser'
import {BookOpen,Check,ExternalLink,Pause,Play,X} from 'lucide-react'
import {db,putBook} from '../db'
import {newBook,type Book} from '../types'
import {normalizeIsbn} from '../isbn'
import {lookupBook} from '../catalog'
import BookEditor from './Editor'

type ScanConfirmation={kind:'added'|'duplicate';book:Book}

export default function Scanner({onClose,onSaved}:{onClose:()=>void;onSaved:()=>void}){
 const video=useRef<HTMLVideoElement>(null),reader=useRef<BrowserMultiFormatReader|null>(null),controls=useRef<IScannerControls|null>(null),busy=useRef(false),seen=useRef('')
 const [active,setActive]=useState(true),[count,setCount]=useState(0),[status,setStatus]=useState('Apunta a un código ISBN na parte traseira do libro.'),[manual,setManual]=useState(''),[pending,setPending]=useState<Book|null>(null),[confirmation,setConfirmation]=useState<ScanConfirmation|null>(null)

 const resumeScanning=()=>{
  setConfirmation(null);setPending(null);seen.current='';busy.current=false;setStatus('Apunta ao seguinte libro para continuar.');setActive(true)
 }

 const handleIsbn=async(isbn:string)=>{
  const current=await db.books.where('isbn').equals(isbn).first()
  if(current){setStatus('ISBN lido. Este libro xa está na biblioteca.');setConfirmation({kind:'duplicate',book:current});return}
  setStatus('ISBN lido. Consultando as fontes bibliográficas…')
  try{
   const info=await lookupBook(isbn),book={...newBook(isbn),titulo:info.title,autor:info.authors,editorial:info.publisher,portada_url:info.cover,xenero:info.genre}
   if(info.found){await putBook(book);setCount(c=>c+1);onSaved();setStatus(`ISBN lido. Comproba: ${book.titulo||'Libro engadido'}.`);setConfirmation({kind:'added',book})}
   else{setPending(book);setStatus(info.networkError?'ISBN lido, sen conexión coas fontes. Completa os datos.':'ISBN lido, pero o libro non aparece nas fontes. Completa os datos.')}
  }catch{setPending({...newBook(isbn)});setStatus('ISBN lido, pero houbo un erro de conexión. Completa os datos manualmente.')}
 }

 const start=useCallback(async()=>{
  if(!video.current)return
  try{
   const hints=new Map();hints.set(DecodeHintType.POSSIBLE_FORMATS,[BarcodeFormat.EAN_13]);hints.set(DecodeHintType.TRY_HARDER,true)
   const r=new BrowserMultiFormatReader(hints,{delayBetweenScanAttempts:250,delayBetweenScanSuccess:250});reader.current=r
   const cameraConstraints:MediaStreamConstraints={video:{facingMode:{ideal:'environment'},width:{ideal:1920},height:{ideal:1080}}}
   controls.current=await r.decodeFromConstraints(cameraConstraints,video.current,(result)=>{
    if(!result||busy.current)return
    const code=normalizeIsbn(result.getText())
    if(!code){setStatus('Código lido, pero non parece un ISBN válido. Céntra os 13 díxitos no marco e proba de novo.');return}
    if(seen.current===code)return
    busy.current=true;seen.current=code;setActive(false);setStatus('ISBN lido. Comprobando o libro…');void handleIsbn(code)
   })
  }catch{setStatus('Non se puido abrir a cámara. Comproba os permisos e a conexión segura.')}
 },[])

 useEffect(()=>{if(active&&!pending&&!confirmation)void start();return()=>{controls.current?.stop();controls.current=null}},[active,pending,confirmation,start])

 const manualAdd=async()=>{
  const isbn=normalizeIsbn(manual)
  if(!isbn){setStatus('ISBN non válido. Revisa os díxitos e téntao de novo.');return}
  busy.current=true;seen.current=isbn;setActive(false);setManual('');setStatus('ISBN introducido. Comprobando o libro…');await handleIsbn(isbn)
 }

 const savePending=async(book:Book)=>{
  await putBook(book);setCount(c=>c+1);onSaved();setPending(null);setStatus(`ISBN lido. Comproba: ${book.titulo||'Libro engadido'}.`);setConfirmation({kind:'added',book})
 }

 return <div className="scanner-page">
  <div className="scanner-top"><button className="back-link" onClick={onClose}><X size={18}/> Finalizar</button><span className="scan-counter"><b>{count}</b> engadidos</span></div>
  <div className="scanner-content">
   <div className="scanner-heading"><span className="eyebrow">ESCANEADO CONTINUO</span><h1>{active?'Mira, enfoca, listo.':'Escáner en pausa.'}</h1><p role="status" aria-live="polite">{status}</p></div>
   <div className="camera-frame"><video ref={video} muted playsInline/><div className="camera-overlay"><span className="corner tl"/><span className="corner tr"/><span className="corner bl"/><span className="corner br"/><div className="scan-line"/></div><span className="camera-help">Sitúa o código de barras dentro do marco</span></div>
   <div className="scanner-actions"><button className="primary-btn" onClick={()=>active?setActive(false):resumeScanning()}>{active?<><Pause size={18}/> Pausar escáner</>:<><Play size={18}/> Retomar escáner</>}</button><span>Tras cada lectura, comproba o libro e continúa cando queiras.</span></div>
   <form className="manual-isbn" onSubmit={e=>{e.preventDefault();void manualAdd()}}><label htmlFor="manual-isbn">Ou introduce un ISBN a man</label><div><input id="manual-isbn" value={manual} onChange={e=>setManual(e.target.value)} placeholder="978-…"/><button className="secondary-btn">Engadir</button></div></form>
  </div>
  {confirmation&&<div className="pending-overlay"><section className="pending-card scan-confirmation" role="dialog" aria-modal="true" aria-labelledby="scan-confirm-title">
   <button className="icon-btn close-pending" aria-label="Continuar escaneando" onClick={resumeScanning}><X/></button>
   <span className="eyebrow">{confirmation.kind==='added'?'LECTURA CONFIRMADA':'XA ESTÁ NA BIBLIOTECA'}</span>
   <h2 id="scan-confirm-title">{confirmation.kind==='added'?'Libro engadido':'ISBN duplicado'}</h2>
   <div className="scan-confirm-book">
    <div className="scan-confirm-cover">{confirmation.book.portada_url?<img src={confirmation.book.portada_url} alt={`Portada de ${confirmation.book.titulo||'libro'}`}/>:<BookOpen size={27}/>}</div>
    <div><strong>{confirmation.book.titulo||'Título non dispoñible'}</strong><span>{confirmation.book.autor||'Autor non dispoñible'}</span><small>ISBN {confirmation.book.isbn}</small>{confirmation.book.editorial&&<small>{confirmation.book.editorial}</small>}</div>
   </div>
   <p>{confirmation.kind==='added'?'Comproba que os datos corresponden a este libro.':'Este ISBN xa estaba gardado; non se engadiu outra copia.'}</p>
   <button className="primary-btn scan-continue" onClick={resumeScanning}><Check size={17}/> Continuar escaneando</button>
  </section></div>}
  {pending&&<div className="pending-overlay"><div className="pending-card">
   <button className="icon-btn close-pending" aria-label="Descartar e continuar escaneando" onClick={resumeScanning}><X/></button>
   <span className="eyebrow">{status.includes('erro')||status.includes('sen conexión')?'ERRO DE CONEXIÓN':'NON ATOPAMOS ESTE LIBRO'}</span><h2>Engádeo manualmente</h2><p>ISBN {pending.isbn} · Enche o que saibas e continúa escaneando.</p>
   <div className="manual-source-links"><a className="manual-source-link" href={`https://www.todostuslibros.com/busquedas?titulo=&autor=&isbn=${encodeURIComponent(pending.isbn)}&editorial=&summary=`} target="_blank" rel="noreferrer">TodoTusLibros <ExternalLink size={14}/></a><a className="manual-source-link" href="https://www.cultura.gob.es/webISBN/cargarLibroBusquedaAvanzada.do?cache=init&language=es&layout=busquedaisbn" target="_blank" rel="noreferrer">Base ISBN do Ministerio <ExternalLink size={14}/></a><a className="manual-source-link" href={`https://www.amazon.es/s?k=${encodeURIComponent(pending.isbn)}`} target="_blank" rel="noreferrer">Buscar en Amazon.es <ExternalLink size={14}/></a></div>
   <BookEditor book={pending} onClose={resumeScanning} onSave={savePending} onDelete={()=>{}}/>
  </div></div>}
 </div>
}
