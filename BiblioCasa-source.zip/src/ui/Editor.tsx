import {useState} from 'react'
import {Check,Trash2,X,BookOpen,ExternalLink} from 'lucide-react'
import {GENRES,type Book} from '../types'
import {normalizeIsbn} from '../isbn'

export default function BookEditor({book,onClose,onSave,onDelete}:{book:Book;onClose:()=>void;onSave:(b:Book)=>void;onDelete:(b:Book)=>void}){
 const [draft,setDraft]=useState<Book>({...book}),[error,setError]=useState('')
 const set=<K extends keyof Book>(key:K,value:Book[K])=>setDraft(d=>({...d,[key]:value}))
 const save=()=>{const isbn=normalizeIsbn(draft.isbn);if(!isbn)return setError('Introduce un ISBN-10 ou ISBN-13 válido.');setError('');onSave({...draft,isbn})}
 const isbn=normalizeIsbn(draft.isbn)
 return <div className="modal-scrim" onMouseDown={e=>e.target===e.currentTarget&&onClose()}><section className="editor-modal">
  <div className="modal-head"><div><span className="eyebrow">FICHA DO LIBRO</span><h2>{book.titulo||'Engadir libro'}</h2></div><button className="icon-btn" onClick={onClose}><X/></button></div>
  <div className="editor-body"><div className="editor-cover"><div className="cover-wrap">{draft.portada_url?<img className="cover-image" src={draft.portada_url} alt="Portada" onError={e=>{e.currentTarget.style.display='none'}}/>:<div className="cover-fallback"><BookOpen size={30}/><span>{draft.titulo||'Portada'}</span></div>}</div><input value={draft.portada_url} onChange={e=>set('portada_url',e.target.value)} placeholder="URL da portada"/></div>
   <div className="editor-fields"><label>Título<input autoFocus value={draft.titulo} onChange={e=>set('titulo',e.target.value)} placeholder="Título do libro"/></label><label>Autor<input value={draft.autor} onChange={e=>set('autor',e.target.value)} placeholder="Nome do autor"/></label><label>Editorial<input value={draft.editorial} onChange={e=>set('editorial',e.target.value)} placeholder="Editorial"/></label><label>Ano de publicación<input inputMode="numeric" value={draft.ano_publicacion} onChange={e=>set('ano_publicacion',e.target.value.replace(/[^0-9]/g,'').slice(0,4))} placeholder="p. ex. 2021" maxLength={4}/></label><label>ISBN<input value={draft.isbn} onChange={e=>set('isbn',e.target.value)} placeholder="978…"/></label>
    {isbn&&<a className="book-source-link" href={`https://www.todostuslibros.com/busquedas?titulo=&autor=&isbn=${encodeURIComponent(isbn)}&editorial=&summary=`} target="_blank" rel="noreferrer">Ver ficha e sinopse en TodoTusLibros <ExternalLink size={14}/></a>}
    <label>Xénero<select value={draft.xenero} onChange={e=>set('xenero',e.target.value as Book['xenero'])}>{GENRES.map(g=><option key={g}>{g}</option>)}</select></label><label className="read-toggle"><input type="checkbox" checked={draft.lido} onChange={e=>set('lido',e.target.checked)}/> Xa lido</label>{error&&<p className="form-error">{error}</p>}
    <div className="form-actions"><button className="primary-btn" onClick={save}><Check size={17}/> Gardar libro</button>{book.isbn&&<button className="delete-btn" onClick={()=>onDelete(book)}><Trash2 size={17}/> Eliminar</button>}</div>
   </div></div>
 </section></div>
}
