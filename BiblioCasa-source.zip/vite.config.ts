import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
import { VitePWA } from 'vite-plugin-pwa'
const base=process.env.GITHUB_PAGES==='true'?'/bibliocasa/':'/'
export default defineConfig({base,plugins:[react(),VitePWA({registerType:'autoUpdate',includeAssets:['icon.svg','icon-192.png'],manifest:{name:'BiblioCasa',short_name:'BiblioCasa',description:'A túa biblioteca persoal, sempre contigo',lang:'gl',theme_color:'#183d32',background_color:'#f6f4ec',display:'standalone',start_url:base,icons:[{src:`${base}icon-192.png`,sizes:'192x192',type:'image/png',purpose:'any maskable'},{src:`${base}icon-512.png`,sizes:'512x512',type:'image/png',purpose:'any maskable'}]},workbox:{navigateFallback:'index.html',globPatterns:['**/*.{js,css,html,png,svg,webmanifest}']}})],server:{host:'0.0.0.0'}})
