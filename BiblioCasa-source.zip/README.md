# BiblioCasa

Aplicación web progresiva para catalogar unha biblioteca física. A base de datos vive no IndexedDB de cada navegador; non hai contas, backend, sincronización nin servizos de almacenamento remoto. As consultas a Google Books e Open Library fanse co ISBN. As portadas cargan desde o provedor que as ofrece.

## Desenvolvemento

Requisitos: Node.js 20.19+ ou 22.12+ e npm.

```sh
npm install
npm run dev
```

Para crear a versión estática de produción:

```sh
npm run build
npm run preview
```

O contido listo para publicar está en `dist/`. Só se precisa servir ficheiros estáticos por HTTPS; non se precisa API propia nin base de datos de servidor. A cámara web só se pode abrir nun contexto seguro (HTTPS ou localhost). Para probar co iPhone, publica `dist/` nun aloxamento estático HTTPS ou usa un túnel HTTPS. Non abonda con abrir o enderezo LAN HTTP do computador.

## Instalar no iPhone

1. Abre o enderezo HTTPS en Safari.
2. Toca **Compartir → Engadir á pantalla de inicio**.
3. Abre BiblioCasa desde a icona. A primeira vez, permite o uso da cámara cando o pida.
4. Na pantalla **Escanear**, mantén o ISBN-13 dentro do marco. A lectura continúa ata que pauses ou finalices.

Se Safari non ofrece a cámara, comproba os permisos do sitio e que o enderezo sexa HTTPS. É posible engadir libros manualmente co ISBN ou crear unha ficha desde **Biblioteca → Engadir libro**.

## Usar no Mac e transferir a biblioteca

Abre o mesmo enderezo HTTPS no navegador do Mac. Cada navegador/dispositivo ten unha base de datos local independente; os cambios non se trasladan por si sós. No iPhone, vai a **Axustes → Copia JSON completa** e escolle onde gardar o ficheiro (por exemplo, Arquivos/iCloud Drive ou AirDrop). No Mac, abre BiblioCasa e usa **Escoller ficheiro JSON**. A fusión identifica duplicados polo ISBN e permite conservar os datos actuais ou substituílos polos da copia. A substitución crea antes unha salvagarda no almacenamento local do dispositivo, ademais da copia que xa exportases.

O ficheiro JSON inclúe versión do formato, data de creación, identificadores, todos os campos e datas. A versión 2 incorpora o ano de publicación; a aplicación tamén acepta copias versión 1 e completa ese campo baleiro ao importalas. O CSV usa separador punto e coma, compatible con configuracións rexionais de Excel. Garda os ficheiros exportados fóra do navegador: limpar datos do sitio pode eliminar IndexedDB.

## Copias e limitacións

Os recordatorios semanal/mensual revísanse cando abres a aplicación e tamén aparecen en Axustes. Unha PWA non pode prometer unha tarefa fiable de exportación ou notificación en segundo plano en iOS. BiblioCasa indica que se preparou unha descarga, pero non pode confirmar que o usuario a garde en iCloud.

Google Books é a primeira fonte automática, Open Library a segunda e o catálogo SRU da Biblioteca Nacional de España a terceira. As respostas exactas combínanse para completar título, autoría, editorial, ano, categorías e, cando está dispoñible, portada. A BNE permite consulta SRU pública por ISBN e os seus rexistros están baixo licenza CC0; a súa cobertura non inclúe todos os libros e normalmente non proporciona portadas neste formato. A comprobación desde a aplicación web recibiu resposta HTTP 200, aínda que o ISBN de proba non tiña rexistro. O validador ISBN-13 só acepta os prefixos 978/979, para non tratar códigos EAN doutros produtos como libros. A cámara pide a cámara traseira e resolución ideal de 1080p.

**Limitación de Google Books:** a API oficial pide unha clave ou token mesmo para datos públicos. A aplicación non inclúe unha clave, e as consultas probadas están a responder coa cota diaria a cero. Polo tanto, mentres non se configure unha clave pública restrinxida á web da aplicación, Open Library é a única fonte automática efectiva. [Documentación de autenticación de Google Books](https://developers.google.com/books/docs/v1/using).

Se ningunha fonte dá un título, a ficha manual ofrece ligazóns a TodoTusLibros, á busca da base de datos de libros editados en España do Ministerio de Cultura e a unha busca de Amazon.es por ISBN. Son consultas web manuais, non extracción automática de datos. Non atopamos unha API pública documentada para consultar automaticamente a base do Ministerio.

As fichas de libros gardados tamén ofrecen unha ligazón a TodoTusLibros para consultar a súa ficha externa e sinopse mediante o ISBN.

DILVE ofrece unha API HTTP para usuarios autorizados, usando as mesmas credenciais que a plataforma; require alta/permisos e cobre os catálogos rexistrados en DILVE, non todos os libros editados en España. A páxina “Tarefas automáticas” describe automatizacións editoriais (como rexistro ISBN e actualizacións de catálogo), non unha busca pública por ISBN. A API de Amazon (Creators API, sucesora de PA-API) tamén require un perfil de Amazon Associates aceptado, 10 vendas cualificadas nos últimos 30 días e credenciais; non se pode chamar de maneira segura desde esta PWA sen expoñelas. Por iso Amazon só está dispoñible como busca manual. [Documentación de acceso á API de Amazon](https://affiliate-program.amazon.com/creatorsapi/docs/en-us/onboarding/register-for-creators-api). Consulta tamén a [documentación da API DILVE](https://web.dilve.es/herramientas/api-de-llamadas-http/) e as [preguntas frecuentes](https://web.dilve.es/asistencia-2/preguntas-frecuentes/).

O navegador pode limitar ou borrar almacenamento local por falta de espazo, decisións do sistema ou limpeza de datos. BiblioCasa solicita a persistencia cando o navegador a admite e informa do resultado; mantén exportacións regulares. A consulta de libros e portadas require conexión. Sen conexión pódense consultar e editar libros xa gardados e introducir datos manualmente.

## Mantemento

- `src/db.ts`: esquema Dexie, persistencia e copias locais previas á restauración.
- `src/catalog.ts`: adaptadores de Google Books, Open Library e BNE SRU, extracción do ano e clasificación fixa.
- `src/isbn.ts`: normalización e validación/checksum ISBN-10/13.
- `src/ui/Scanner.tsx`: cámara ZXing, escaneado continuo e ISBN manual.
- `src/ui/App.tsx`, `src/ui/Editor.tsx`, `src/ui.css`: navegación, vistas, fichas e estilos.
- `vite.config.ts`: manifest e Service Worker da PWA. O Service Worker almacena recursos da aplicación; a biblioteca mantense en IndexedDB.

Dependencias principais: React, TypeScript, Vite, Dexie, ZXing e lucide-react. Non hai SDK de backend.

## Validación pendiente

A compilación de produción execútase con `npm run build`. A validación de cámara con códigos reais, permisos de Safari, instalación en iPhone/Mac e probas de transferencia entre dispositivos require dispositivos e unha publicación HTTPS; non se simula neste proxecto.
